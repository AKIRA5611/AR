#include "Data.h"
int  ModelClass::Data_Load(){
  puts("Data_load inside");
    char **strbox=new char *[box_num+1];
    for(int i=0;i<box_num+1;i++)
	strbox[i]=new char [32];

    strcpy(strbox[0],"Data/Model/box.mqo");
    strcpy(strbox[1],"Data/Model/bluebox.mqo");
    strcpy(strbox[2],"Data/Model/redbox.mqo");
    strcpy(strbox[3],"Data/Model/purplebox.mqo");
    strcpy(strbox[Wall_num],"Data/Model/wall.mqo");
    printf("%s%s%s",strbox[0],strbox[1],strbox[2]);
    for(int i=0;i<box_num+1;i++){
        puts("checl");
	Box[i]=mqoCreateModel(strbox[i],(i!=Wall_num ? size_scale :size_scale*10.0));
	if(Box[i]==NULL){
	    printf("box=%s is not found\n",strbox[i]);
	    return -1;
	}
    }

    printf("fsaf");
    for(int i=0;i<box_num+1;i++)
	delete [] strbox[i];
    delete [] strbox;

    return 0;
}

//Font Class
int FontClass::convert(char *inbuf, char *outbuf, size_t os)
{
    iconv_t conv;
    char    *in, *out;
    size_t  is;

    in = inbuf;
    out = outbuf;
    is = (size_t)(strlen(inbuf)+1);

    if ((conv = iconv_open("WCHAR_T", "EUC-JP")) == (iconv_t)(-1)) return (1);	// can't open 
    if (iconv(conv, &in, &is, &out, &os) == (size_t)(-1)) return (2);	// can't convert
    iconv_close(conv);
    return (0);
}

void FontClass::drawString(FTFont *font, char *str)
{
    char   outstr[256];
    float  llx, lly, llz;
    float  urx, ury, urz;

    if (convert(str, outstr, 256)) return;

    font->BBox((wchar_t *)outstr, llx, lly, llz, urx, ury, urz);
    glPushMatrix();
    glTranslatef(-(llx+urx)/2.0, -(lly+ury)/2.0, 0.0);
    font->Render((wchar_t *)outstr);
    glPopMatrix();
}

void FontClass::RenderFont(char *str,float pos_x,float pos_y){
    int width=0;
    int i=0;
    glPushMatrix();
    glTranslatef(110.0f+pos_x,50.0f+pos_y,Map_depth);
    glScalef(3.0f,3.0f,3.0f);
    drawString(font,str);
    //glutStrokeCharacter(GLUT_STROKE_ROMAN,str[i-1]);
    //width+=glutStrokeWidth(GLUT_STROKE_ROMAN,str[i-1]);
    //glutBitmapCharacter(GLUT_BITMAP_9_BY_15,str[i-1]);
    //width+=glutBitmapWidth(GLUT_BITMAP_9_BY_15,str[i-1]);
    glPopMatrix();

}
