#include "MyModule.h"
//Global Scope Method//



//ModelClass//


//Basic AR Class//

/*Basic_AR_Class::~Basic_AR_Class(){
    nyar_NyARTransMat_O2_free(nyobj);
    mqoCleanup();
    arVideoCapStop();
    arVideoClose();
    argCleanup();
}*/

void Game_Class::DrawGame(FieldClass &f,PieceClass &p,ModelClass &model,FontClass &font)
{
    char *str1="Score";
    char *str2="GameOver";
    char buf[16];
    sprintf(buf,"%d",score);
    double gl_para[16];
    argDrawMode3D();
    argDraw3dCamera(0, 0);
    argConvGlpara(patt_trans,gl_para);
    glMatrixMode(GL_MODELVIEW);
    glLoadMatrixd(gl_para);
    this->SetLight();

    glClear(GL_DEPTH_BUFFER_BIT);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glTranslatef(0.0f,0.0f,100.0f);
    //  glRotatef(0.0,1.0,0.0,0.0);

    p.Render_next(model.returnBox());

    f.Render(model.returnBox());
    puts("Render,REnder,De");
    // model.ModelRender();
    if(GameOver==false){
	p.Render(model.returnBox());
	font.RenderFont(str1,0,0);
	font.RenderFont(buf,60,0);
    }
    else{
	font.RenderFont(str2,0,0);
    }
    glDisable(GL_LIGHTING);
    glDisable(GL_DEPTH_TEST);
}

void Basic_AR_Class::SetLight(){
    GLfloat light_diffuse[] ={0.2,0.2,0.5,0.2};
    GLfloat light_specular[]={1.0, 1.0, 1.0, 1.0};
    GLfloat light_ambient[] ={0.2, 0.3, 0.3 ,0.1};
    GLfloat light_position[]={100.0, 200.0, 200.0, 0.0};

    glLightfv(GL_LIGHT0,GL_DIFFUSE,light_diffuse);
    glLightfv(GL_LIGHT0,GL_SPECULAR,light_specular);
    glLightfv(GL_LIGHT0,GL_AMBIENT,light_ambient);
    glLightfv(GL_LIGHT0,GL_POSITION,light_position);

    glShadeModel(GL_SMOOTH);

    glEnable(GL_LIGHT0);

}

void Basic_AR_Class::SetMaterial(){
    GLfloat mat_diffuse[]   ={1.0, 0.0, 0.0, 0.0};
    GLfloat mat_specular[]  ={0.0, 0.0, 1.0, 1.0};
    GLfloat mat_ambient[]   ={0.0, 0.0, 1.0, 1.0};
    GLfloat shine[]	    ={50.0};
    glMaterialfv(GL_BACK,GL_DIFFUSE,mat_diffuse);
    glMaterialfv(GL_BACK,GL_SPECULAR,mat_specular);
    glMaterialfv(GL_BACK,GL_AMBIENT,mat_ambient);
    glMaterialfv(GL_BACK,GL_SHININESS,shine);

}

int Basic_AR_Class::Init(){

    int xsize,ysize;

    if(arVideoOpen(vconf_name)<0){
	puts("video device error");
	return -1;
    }

    if(arVideoInqSize(&xsize,&ysize) < 0)
	return -1;

    if(arParamLoad(cparam_name,1,&wparam)< 0){
	puts("param load error");
	return -1;
    }

    arParamChangeSize(&wparam,xsize,ysize,&cparam);
    arInitCparam(&cparam);
    nyobj = nyar_NyARTransMat_O2_create(&cparam);

    if( (patt_id=arLoadPatt(pattern_name)) < 0){
	puts("pattaern load error");
	return -1;
    }
    if ((gArglSettings = arglSetupForCurrentContext()) == NULL) {
      fprintf(stderr, "main(): arglSetupForCurrentContext() returned error.\n");
      return -1;
    }
    puts("argInit before");
    argInit(&cparam, 1.0, 0, 0, 0, 0); 
    arVideoCapStart();
    arUtilTimerReset();


return 0;
}

void Basic_AR_Class::AR_Mat(){

    if(isFirst==true)
	nyar_NyARTransMat_O2_transMat(nyobj,&marker_info[k],patt_center,patt_width,patt_trans);
    else
	nyar_NyARTransMat_O2_transMatCont(nyobj,&marker_info[k],patt_trans,patt_center,patt_width,patt_trans);

    isFirst=false;
}


//Game Class

void Game_Class::InitGame(FieldClass &f,PieceClass &p){
  puts("Call_InitGame");
    f.Init();
    if(First){
	p.CreatePiece();
	First=false;
    }
    p.SwapPiece();
    p.CreatePiece();
    score =0;
    GameOver=false;
    isFirst=true;
    puts("Game_Class::InitGame_End");
}

void Game_Class::Set_GameOver(FieldClass &f,PieceClass &p){
    GameOver=GameOverCheck(f,p);
}
void Game_Class::Key_React(unsigned char key,FieldClass &f,PieceClass &p){
    if(key==0x1b)
	exit(0);
    this->Set_GameOver(f,p);
    if(GameOver==true)
	return;

    if(key=='a')
	MovePiece(move_l,f,p);
    if(key=='d')
      MovePiece(move_r,f,p);
    if(key=='w')
      MovePiece(move_f,f,p);
    if(key=='z')
      MovePiece(move_b,f,p);
    if(key=='j')
	RolePiece(role_1,f,p);
    if(key=='h')
	MovePiece(role_2,f,p);
    if(key==' ')
      MovePiece(warp,f,p);

}
void Game_Class::Auto_Game(FieldClass &f,PieceClass &p,ModelClass &model,FontClass &font){
  puts("Auto_Game");
    if(k!=-1) {

	AR_Mat(); 


	if(Get_GameOver()==false){
	    if(arUtilTimer()>1.0){
		this->Set_GameOver(f,p);
		if(GameOver==false)
		    MovePiece(999,f,p);

		score+=f.ShiftPiece(f.deletePiece());
		arUtilTimerReset();

	    }
	}
	else{
	    if(arUtilTimer()>15.0)
		this->InitGame(f,p);
	    
	}
	this->DrawGame(f,p,model,font);
    }
}
#ifndef _WIN32
double Game_Class::gettimeofday_sec()
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec + (double)tv.tv_usec*1e-6;
}

void Game_Class::Wait(double wait_time){
    double start_time=gettimeofday_sec();
    while(gettimeofday_sec()<wait_time+start_time)
	if(wait_time>0)usleep(1000);
}

void Game_Class::FPSCount(){

    static double before=gettimeofday_sec();
    double now=gettimeofday_sec();
    static DWORD fps_ctr=0;

    if(now-before>=1.000){
	before=now;
	fps=fps_ctr;
	fps_ctr=0;

    }
    fps_ctr++;
}

#else
void Game_Class::Wait(DWORD wait_time){
    DWORD start_time=timeGetTime();
    while(timeGetTime()<wait_time +start_time)
	if(wait_time>0)Sleep(1);

}
void Game_Class::FPSCount(){

    static DWORD before=timeGetTime();
    DWORD now=timeGetTime();
    static DWORD fps_ctr=0;

    if(now-before>=1000){
	before=now;
	fps=fps_ctr;
	fps_ctr=0;
    }
    fps_ctr++;
}

void Game_Class::Wait_FPS_Func(DWORD PassTime){

    (1000/FPS>PassTime)? Wait(1000/FPS-PassTime):Wait(0);


}

#endif
