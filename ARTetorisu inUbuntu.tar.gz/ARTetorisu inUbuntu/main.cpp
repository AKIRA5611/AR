#include "MyModule.h"
//extra parameter

void MainLoop();
void KeyEvent(unsigned char key,int x,int y);
void MouseEvent(int button,int state,int x,int y);

FieldClass f;
PieceClass p;
ModelClass model;
FontClass font;
Game_Class GM;

int main(int argc,char**argv){

  puts("hello_dddd");
  glutInit(&argc,argv);

  if(GM.Init()==-1)
    return -1;
  mqoInit();
  puts("Data_Load_before");
  model.Data_Load();
  puts("Data_load_after");
  GM.InitGame(f,p);
  puts("mono");
#ifdef _WIN32
  TIMECAPS Caps;
  timeGetDevCaps(&Caps, sizeof(TIMECAPS)); // ���\�擾
  timeBeginPeriod(Caps.wPeriodMin);
#endif
  argMainLoop(MouseEvent,KeyEvent,MainLoop);
#ifdef _WIN32
  timeEndPeriod(Caps.wPeriodMin);
#endif
  return 0;
}


void MainLoop()
{
  //QueryPerformanceFrequency(&nFreq);
  //QueryPerformanceCounter(&nBefore);

  DWORD StartTime,EndTime,PassTime;
  double l_StartTime,l_EndTime,l_PassTime;
#ifdef _WIN32
  StartTime=timeGetTime();
#else
  l_StartTime=GM.gettimeofday_sec();
#endif


  puts("zi");
  if(GM.CatchMarker()==-1)return;
  GM.Auto_Game(f,p,model,font);
  argSwapBuffers();
#ifdef _WIN32
  EndTime=timeGetTime();
  PassTime=EndTime-StartTime;
  GM.Wait_FPS_Func(PassTime);
  GM.FPSCount();
  GM.showFPS();
#else
  /*
    l_EndTime=gettimeofday_sec();
    l_PassTime=l_EndTime-l_StartTime;
    ((double)(1000/FPS)>l_PassTime)?Wait((double)1000/FPS-l_PassTime):Wait(0);
    FPSCount(&fps);
    printf("FPS=%d\n",fps);*/
#endif

}

void KeyEvent(unsigned char key,int x,int y){
  GM.Key_React(key,f,p);
}

void MouseEvent(int button,int state,int x,int y){
  //printf("�{�^��:%d ��ԁF%d ���W�F(x�Ay)=%d,%d\n",button,state,x,y);
}












