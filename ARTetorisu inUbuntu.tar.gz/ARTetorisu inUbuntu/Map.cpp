/*
�S�̓I�ȕ\��

�X�R�A

�Q�[���Z���N�g

NPC

�ΐ�

��̈��

�Q�[���I�[�o�[

�g��

���_�ړ�

�����߃Q�[��

�悯�Q�[��
*/
#include "Map.h"
//bit��ł��񂴂��������킽���Ƃ��������[
void PieceClass::Render(MQO_MODEL *MyModel){
  for(int i=0;i<box_num;i++){
    glPushMatrix();
    glTranslatef(block_size*(pos_x+Piece[i].x),block_size*(pos_y+Piece[i].y),-block_size*(Piece[i].z+pos_z));
    mqoCallModel(MyModel[PieceColor]);
    glPopMatrix();
  }
  //puts("Render,Render");
    
}
void PieceClass::Render_next(MQO_MODEL *MyModel){

  /*   for (int i=Piece_Height-1;i>=0;i--)
	for (int j=0;j<Piece_Width;j++)
	    if(next_Piece[j][i]==true){
		glPushMatrix();
		glTranslatef(block_size*(j+next_pos_x),-block_size*(i+next_pos_y),Map_depth);
		mqoCallModel(MyModel[next_PieceColor]);
		glPopMatrix();

		}*/
  /* for(int i=0;i<box_num;i++){
    glPushMatrix();
    glTranslatef(block_size*(pos_x+Next_Piece[i].x),-block_size*(pos_y+Next_Piece[i].y),block_size*(Next_Piece[i].z+pos_z));
    mqoCallModel(MyModel[PieceColor]);
    glPopMatrix();
    }*/
}

void FieldClass::Render(MQO_MODEL *MyModel){
    int count=0;
    for(int d=Map_Depth-1;d>=0;d--){
      for (int i=Map_Height-1;i>=0;i--)
	for (int j=0;j<Map_Width;j++)
	  if(Field[j][i][d]==true){
	    printf("j=%d,i=%d,j=%d\n",j,i,d);
	    puts("fresh");
	    count++;
	    glPushMatrix();
	    glTranslatef(block_size*j,-block_size*i,-block_size*d);
	    mqoCallModel( MyModel[FieldColor[j][i][d]] );
	    glPopMatrix();
	  }
      if(count==0)
	return;
      count=0;
    }
}
void PieceClass::CreatePiece(){
  vec box[4];
    switch(rand()%7){
	//���P�[�X����̂��@�s�� 14
	/*
	Color
	0 green
	1 blue
	2 red
	3 purple
	*/
      puts("Createtion notice");
case 0:
  //next_Piece[1][1]=next_Piece[2][1]=next_Piece[0][1]=next_Piece[1][0]=true;
  box[0].x=1,box[0].y=1,box[1].x=1, box[1].y=2, box[2].x=2, box[2].y=1,box[3].x=2,box[3].y=2;
    break;
case 1:
  // next_Piece[1][1]=next_Piece[2][1]=next_Piece[1][2]=next_Piece[2][2]=true;
  box[0].x=1,box[0].y=1,box[1].x=0, box[1].y=1, box[2].x=1, box[2].y=2,box[3].x=2,box[3].y=1;
    break;
case 2:
  //next_Piece[1][0]=next_Piece[1][1]=next_Piece[1][2]=next_Piece[1][3]=true;
  box[0].x=1,box[0].y=1,box[1].x=1, box[1].y=2, box[2].x=0, box[2].y=2,box[3].x=2,box[3].y=1;
    break;
case 3:
  //next_Piece[1][0]=next_Piece[1][1]=next_Piece[1][2]=next_Piece[0][2]=true;
  box[0].x=1,box[0].y=1,box[1].x=0, box[1].y=1, box[2].x=1, box[2].y=2,box[3].x=2,box[3].y=2;
    break;
case 4:
  //next_Piece[1][0]=next_Piece[1][1]=next_Piece[1][2]=next_Piece[2][2]=true;
  box[0].x=1,box[0].y=1,box[1].x=0, box[1].y=1, box[2].x=1, box[2].y=2,box[3].x=1,box[3].y=3;
    break;
case 5:
  //next_Piece[1][1]=next_Piece[0][1]=next_Piece[1][2]=next_Piece[2][2]=true;
  box[0].x=1,box[0].y=1,box[1].x=2, box[1].y=1, box[2].x=1, box[2].y=2,box[3].x=1,box[3].y=3;
    break;
case 6:
  //next_Piece[1][1]=next_Piece[2][1]=next_Piece[0][2]=next_Piece[1][2]=true;
  box[0].x=1,box[0].y=1,box[1].x=1, box[1].y=0, box[2].x=1, box[2].y=2,box[3].x=1,box[3].y=3;
    break;
    }

    for(int i=0;i<box_num;i++){
      box[i].z=0;
      Next_Piece[i]=box[i];
    }
    next_PieceColor=rand()%4;
    next_pos_x=next_pos_y=next_pos_z=0;
    puts("Createion End");
}

bool GameOverCheck(FieldClass &f,PieceClass &p){
//�t�B�[���h�̈�ԏ�𒲂ׂ�
//��ԏ�ƁA�s�[�X�̈�ԏ�̃}�X�𒲂ׂ�B
/*
    for(int i=0;i<Piece_Height;i++)
	for(int j=0;j<Piece_Width;j++)
	    if(p.Piece[j][i]){
		if(f.Field[0+j][0+i]){
                    puts("hwllo");
		    return true;

		}
	    }
*/
  for(int i=0;i<box_num;i++)
    if(p.Piece[i].z+p.pos_z<0)
      return true;

    return false;
}

void MovePiece(int KeyDown,FieldClass &f,PieceClass &p){
    //Stop and write Filed method is not written yet......
  int possible_count=0;
  if(KeyDown==999){
    for(int i=0;i<box_num;i++)
      if(p.OverCheck(i,0,0)==true)
	if(f.Field[p.pos_x+p.Piece[i].x][p.pos_y+p.Piece[i].y][p.pos_z+p.Piece[i].z+1]==false && p.DownCheck(i)==true)
	  possible_count++;

    if(possible_count==box_num)
      p.pos_z++;
    else{
      for(int i=0;i<box_num;i++){
	 printf("j=%d,i=%d,j=%d\n",p.pos_x+p.Piece[i].x,p.pos_y+p.Piece[i].y,p.pos_z+p.Piece[i].z);
	f.Field[p.pos_x+p.Piece[i].x][p.pos_y+p.Piece[i].y][p.pos_z+p.Piece[i].z]=true;
	f.FieldColor[p.pos_x+p.Piece[i].x][p.pos_y+p.Piece[i].y][p.pos_z+p.Piece[i].z]=p.PieceColor;
	puts("superrender");
      }
      p.SwapPiece();
      p.CreatePiece();
    }

  }

  else if(KeyDown==44){

  }

  else{
    int vel_x=(int)cos((double)KeyDown*3.14/180.0);
    int vel_y=(int)sin((double)KeyDown*3.14/180.0);
    /*int x_min=100;
      int y_min=100;
      int x_max=-1;
      int y_max=-1;//�悤����ɍ��E�̌��E������ƁA�j
      for(int i=0;i<box_num;i++){
      x_max=(x_max<Piece[i].x)? Piece[i].x:x_max;
      y_max=(y_max<Piece[i].y)? Piece[i].y:y_max;
      x_min=(x_min>Piece[i].x)? Piece[i].x:x_min;
      y_min=(y_min>Piece[i].y)? Piece[i].y:y_min;
      }*/
   
    for(int i=0;i<box_num;i++)
      if(f.Field[p.pos_x+p.Piece[i].x+vel_x][p.pos_y+p.Piece[i].y+vel_y][p.pos_z+p.Piece[i].z]==false && p.OverCheck(i,vel_x,vel_y)==true)
	possible_count++;

    if(possible_count==box_num)
      p.pos_x+=vel_x,p.pos_y+=vel_y;
  
  }


}
/*
int PieceClass::GetLeftLimit(){
    int position=0;//x
    for(int i=0;i<Piece_Width;i++)
	for (int j=0;j<Piece_Height;j++)
	    if(Piece[i][j])
		return j;

}
//�����悤�ȏ����𓯂��悤�ɏ����Ȃ��̂͂ނ���

int PieceClass::GetRightLimit(){
    int position=0;//x
    for(int i=Piece_Width-1;i>=0;i--)
	for (int j=0;j<Piece_Height;j++)
	    if(Piece[i][j])
		return j;
}

int PieceClass::GetUpLimit(){

    for(int i=0;i<Piece_Height;i++)
	for(int j=0;i<Piece_Width;j++)
	    if(Piece[j][i])
		return i;
}


int PieceClass::GetBottomLimit(){
    for(int i=Piece_Height-1;i>=0;i--)
	for (int j=0;j<Piece_Width;j++)
	    if(Piece[j][i])
		return i;
}
*/

void PieceClass::SwapPiece(){
  for(int i=0;i<box_num;i++)
    Piece[i]=Next_Piece[i];
  pos_x=pos_y=pos_z=0;
  PieceColor=next_PieceColor;
}


DelInfo FieldClass::deletePiece(){
    int del_num=0,del_z=0;
    for(int d=0;d<Map_Depth;d++){
	int count=0;
	for(int i=0;i<Map_Width;i++)
	  for(int j=0;j<Map_Height;j++)
	    if(Field[i][j][d])count++;

	if(count==0)break;
	else if((Map_Width*Map_Height)==count){
	    for(int i=0;i<Map_Width;i++)
	      for(int j=0;j<Map_Height;j++)
		Field[i][j][d]=false;

	    del_num++;
	    del_z=d;
	}
    }
    DelInfo Del;
    Del.del_num=del_num;
    Del.del_z=del_z-1;

    return Del;
}
int FieldClass::ShiftPiece(DelInfo del){
    int shift_num=del.del_num;
    int count=0;
    for(int d=del.del_z+1;d<Map_Depth;d++){
	for (int i=0;i<Map_Width;i++)
	  for(int j=0;j<Map_Height;j++)
	    if(Field[i][j][d])count++;

	if(count==0)break;
	for(int i=0;i<Map_Width;i++)
	  for(int j=0;j<Map_Height;j++){
	    Field[i][j][d-del.del_num]=Field[i][j][d],Field[i][j][d]=false;
	    FieldColor[i][j][d-del.del_num]=FieldColor[i][j][d];
	  }
    }

    return del.del_num*10;
}

/* 5 block ver
void RolePiece(int KeyDown,FieldClass &f_obj,PieceClass &p_obj){
//����[2][2]�̎����90�x��]�����A���W�̌��_�����[�Ɉڂ��ƁA�����Ȃ�܂��B
//If upper Limit bug happen ,I write code again!
PieceClass tmp=p_obj;
for (int i=0;i<Piece_Width;i++)
for(int j=0;j<Piece_Height;j++)
if(tmp.Piece[i][j]){
if(p_obj.pos_x+j<0 || p_obj.pos_x+j>=Map_Width
|| p_obj.pos_y + 4 -i>=Map_Height)
return;
if(f_obj.Field[p_obj.pos_x+j][p_obj.pos_y + 4 -i])
return;
}


for (int i=0;i<Piece_Width;i++)
for(int j=0;j<Piece_Height;j++){
if(p_obj.Piece[i][j]){
tmp.Piece[i][j]=false;
tmp.Piece[j][4-i]=true;
}
p_obj=tmp;
}	
}
*/
bool PieceClass::OverCheck(int index,int x_result,int y_result){
 
 int  now_x=pos_x+Piece[index].x+x_result;
 int now_y=pos_y+Piece[index].y+y_result;
  if(now_x<0 || now_x >Map_Width-1
     || now_y <0 || now_y >Map_Height-1)
    return false;

  return true;
}
bool PieceClass::DownCheck(int index){
       if(pos_z+Piece[index].z <0 || pos_z+Piece[index].z+1 >=Map_Depth)
    return false;

  return true;
}
void RolePiece(int KeyDown,FieldClass &f,PieceClass &p){
    //����[2][2]�̎����90�x��]�����A���W�̌��_�����[�Ɉڂ��ƁA�����Ȃ�܂��B
    //If upper Limit bug happen ,I write code again!
  if(KeyDown==0){
    for(int i=0;i<box_num;i++)
      if(f.Field[p.pos_x+p.Piece[i].y-1][p.pos_y+1-p.Piece[i].x][p.pos_z+p.Piece[i].z]
	 || p.OverCheck(i,0,0)==false)
	return;

    for(int i=0;i<box_num;i++){
      int tmp=p.Piece[i].x;
      p.Piece[i].x=p.Piece[i].y-1;
      p.Piece[i].y=1-tmp;
    }


  }
  else if (KeyDown==1){
    for(int i=0;i<box_num;i++)
      if(f.Field[p.pos_x+p.Piece[i].z][p.pos_y+p.Piece[i].y][p.pos_z+1-p.Piece[i].x]
	 || p.OverCheck(i,0,0)==false)
	return;

    for(int i=0;i<box_num;i++){
      int tmp=p.Piece[i].x;
      p.Piece[i].x=p.Piece[i].z;
      p.Piece[i].z=1-tmp;
    }

  }

    
}

void FieldClass::Init(){
    memset(Field,'\0',sizeof(Field));
    memset(FieldColor,'\0',sizeof(FieldColor));
}
