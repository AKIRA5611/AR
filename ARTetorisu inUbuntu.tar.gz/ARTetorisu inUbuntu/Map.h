#ifndef _GL

#ifdef _WIN32
#include<windows.h>
#pragma comment(lib,"opengl32.lib")
#pragma comment(lib,"glu32.lib")
#pragma comment(lib,"glut32.lib")
#endif

#include <cstring>
#include <cstdlib>
#include<cmath>
#include<GL/gl.h>
#include<GL/glu.h>
#include<GL/glut.h>
#include "GLMetaseq.h"
#include<vector>
using namespace std;
static const int  Map_Width =6;
static const int Map_Height =6;
static const int Map_Depth=10;//3dTetorisu
static const float block_size=10.0f;
static const int box_num=4;
static const float Map_depth=20.0f;

typedef struct{
    int del_num;
    int del_z;//�������u���b�N�̒��ŁA�ł�������y���W�̃u���b�N�̂���ɁA�ЂƂ��B�i�v���O�����I���W�j
}DelInfo;

typedef struct{
  int x;
  int y;
  int z;
}vec;

class PieceClass;

class FieldClass{

private:
    bool Field[Map_Width][Map_Height][Map_Depth];
    unsigned int FieldColor[Map_Width][Map_Height][Map_Depth];
public:
    FieldClass(){
      puts("hello");
      memset(&Field,'\0',sizeof(Field));
      memset(&FieldColor,'\0',sizeof(FieldColor));
    }
    friend void MovePiece(int KeyDown,FieldClass &f,PieceClass &p);
    friend void RolePiece(int KeyDown,FieldClass &f,PieceClass &p);
    DelInfo deletePiece();
    int ShiftPiece(DelInfo del);
    void Render(MQO_MODEL *MyModel);
    friend bool GameOverCheck(FieldClass &f,PieceClass &p);
    void Init();
};

class PieceClass{
 private:
  // bool Piece[Piece_Width][Piece_Height][Piece_Depth];
  vector<vec> Piece;
  unsigned int PieceColor;
  int pos_x,pos_y,pos_z;
  int next_pos_x,next_pos_y,next_pos_z;
  //bool next_Piece[Piece_Width][Piece_Height][Piece_Depth];
  vector<vec> Next_Piece;
  unsigned int next_PieceColor;
 public:
    PieceClass(){
      //	memset(&Piece,'\0',sizeof(Piece));
	pos_x=pos_y=pos_z=0;
	next_pos_x=2;
	next_pos_y=2;
	next_pos_z=0;
	//	memset(&next_Piece,'\0',sizeof(next_Piece));
	Piece.reserve(sizeof(vec)*4);
	Next_Piece.reserve(sizeof(vec)*4);
	puts("piece debug");
    }
    void CreatePiece();
    friend void MovePiece(int KeyDown,FieldClass &f_obj,PieceClass &p_obj);
    friend void RolePiece(int KeyDown,FieldClass &f_obj,PieceClass &p_obj);
    friend bool GameOverCheck(FieldClass &f,PieceClass &p);
    void SwapPiece();
    /*
    int GetLeftLimit();
    int GetRightLimit();
    int GetUpLimit();
    int GetBottomLimit();
    */
    bool OverCheck(int index,int x_result,int y_result);
    bool DownCheck(int index);
    void Render(MQO_MODEL *MyModel);
    void Render_next(MQO_MODEL *MyModel);

};
#define _GL
#endif 
