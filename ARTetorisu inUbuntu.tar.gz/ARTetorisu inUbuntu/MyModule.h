#ifndef _MYMODULE

#ifdef _WIN32
#ifdef DEBUG
#pragma comment(lib,"libARd.lib")
#pragma comment(lib,"libARgsubd.lib")
#pragma comment(lib,"libARvideod.lib")
#else
#pragma comment(lib,"libAR.lib")
#pragma comment(lib,"libARgsub.lib")
#pragma comment(lib,"libARvideo.lib")
#endif

#pragma comment(lib,"ftgl.lib")
#pragma comment(lib,"freetype2311.lib")
#pragma comment(lib,"libiconv.lib")
#endif
#include<cstdio>
#include<AR/ar.h>
#include<AR/param.h>
#include<AR/gsub.h>
#include<AR/gsub_lite.h>
#include<AR/video.h>
#include"nyar_NyARTransMat.h"
#include"Data.h"
#ifndef _WIN32
#include <time.h>
#include <sys/time.h>
#include<unistd.h>
#endif

#ifndef _WIN32
typedef unsigned long DWORD;
#endif
static char *mobname="Data/Model/box.mqo";
class Game_Class;
class FontClass;




class Basic_AR_Class{

private:
    ARParam cparam;
    ARParam wparam;
    nyar_NyARTransMat_O2_t *nyobj;
    int   patt_id;
    double patt_center[2];
    double patt_width;
    int thresh;
    ARUint8		*image;
    ARMarkerInfo	*marker_info;
    int			 marker_num;
    int			 j;
    char *vconf_name;
    char *pattern_name;
    char *cparam_name;
    //opnegl basic settings
    ARGL_CONTEXT_SETTINGS_REF gArglSettings;
public:
    int k;
    double patt_trans[3][4];
    bool isFirst;
    Basic_AR_Class(){
      puts("basic class");
      vconf_name=NULL;
      pattern_name = new char[32];
      cparam_name=new char[32];
      //strcpy(vconf_name,"Data/WDM_camera_flipV.xml");
      strcpy(pattern_name,"Data/patt.hiro");
      strcpy(cparam_name,"Data/camera_para.dat");
      patt_center[0]=0.0;
      patt_center[1]=0.0;
      patt_width=80.0;
      isFirst=false;
      thresh=100.0;
    }
    int Init();
    void SetMaterial();
    void SetLight();
    void AR_Mat();
    int CatchMarker(){

	if( (image = (ARUint8*)arVideoGetImage() )==NULL){
	    arUtilSleep(2);
	    return -1;
	}
	argDrawMode2D();
	arglDispImage(image,&cparam, 1.0, gArglSettings);

	if(arDetectMarker(image, thresh, &marker_info, &marker_num) < 0){
	    exit(0);
	}

	arVideoCapNext();
	printf("hello debug3\n");
	k=-1;
	for(j=0;j<marker_num;j++){   
	    if(patt_id==marker_info[j].id){
		k = (k==-1)  ?   j : k;
		k = (marker_info[k].cf < marker_info[j].cf)   ?  j: k;
	    }
	}
	return 0;
    }
    ~Basic_AR_Class(){
	delete [] pattern_name;
	delete [] cparam_name;
	nyar_NyARTransMat_O2_free(nyobj);
	mqoCleanup();
	arVideoCapStop();
	arVideoClose();
	argCleanup();
    }
};

class Game_Class :public Basic_AR_Class{
private:
  bool First;
  bool Black_out;
  bool GameOver;
  int score;
  static const DWORD FPS=60;
  static const int move_f=90;
  static const int move_b=270;
  static const int move_r=0;
  static const int move_l=180;
  static const int move_d=999;
  static const int warp=44;
  static const int role_1=0;
  static const int role_2=1;
  DWORD fps;
public:
    Game_Class(){
      puts("gameclass");
	First=true;
	GameOver=false;
	score=0;
    }
    void InitGame(FieldClass &f,PieceClass &p);
    void DrawGame(FieldClass &f,PieceClass &p,ModelClass &model,FontClass &font);
    void Key_React(unsigned char key,FieldClass &f,PieceClass &p);
    void Auto_Game(FieldClass &f,PieceClass &p,ModelClass &model,FontClass &font);
    void Set_GameOver(FieldClass &f,PieceClass &p);
    bool Get_GameOver(){
	return GameOver;
    }
#ifndef _WIN32
    double gettimeofday_sec();
    void Wait(double wait_time);
    void FPSCount();
#else
    void Wait_FPS_Func(DWORD PassTime);
    void Wait(DWORD wait_time);
    void FPSCount();
    void showFPS(){
	printf("FPS=%d\n",fps);
    }
#endif
};

#define _MYMODULE
#endif
