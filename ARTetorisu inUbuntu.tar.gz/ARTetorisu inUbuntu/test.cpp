#include<vector>
#include<iostream>
#include<algorithm>
using namespace std;
typedef struct{
  int x;
  int y;
  int z;
}vec;

/*class LessInt{
public:
  bool operator()(const vec& left,const vec& right){
    if(left.x<right.x)
      return true;
    else 
      return false;
  }

};*/
bool compare(const vec& left,const vec& right){return (left.x<right.x);}

int main(){
  vector<vec> array(4);

  array[0].x=2;
  array[1].x=4;
  array[2].x=1;
  array[3].x=5;

  sort(array.begin(),array.end(),compare);

  
  cout<<array[2].x<<endl;
  // for(int i=0;i<4;i++)
  // array.push_back(2,2);
  // for(int i=0;i<4;i++)
  // cout<<array[i].first<<endl;

  return 0;
}
