#ifndef _DATA
#include "Map.h"
#include<FTGL/FTGLPolygonFont.h>
#include <iconv.h>
class ModelClass{
private:
    static const int Wall_num=4;
    double size_scale;
int x;
    MQO_MODEL Box[box_num+1];
public:
    int Data_Load();
    ModelClass(){
      puts("model");
	size_scale=0.05;
    }

    MQO_MODEL* returnBox(){
	return Box;
    }
    void ModelRender(){
	glPushMatrix();
	glTranslatef(0,0,Map_depth);
	mqoCallModel(Box[Wall_num]);
	glPopMatrix();
    }
    ~ModelClass(){
	if(Box!=NULL)
	    for (int i=0;i<box_num+1;i++)
		mqoDeleteModel(Box[i]);
    }
    void CleanUp(){
	if(Box!=NULL)
	    for (int i=0;i<box_num+1;i++)
		mqoDeleteModel(Box[i]);
    }
};

class FontClass{
private:
    char* FONT;
    float FONT_SIZE;
    FTFont *font;
public:
    FontClass(){
	FONT =new char [32];
	FONT_SIZE=10.0;
	strcpy(FONT,"Data/PLANA___.TTF");
	font =new FTGLPolygonFont(FONT);
	if(font->Error())exit(1);
	if(!font->FaceSize(FONT_SIZE))exit(1);
	if(!font->CharMap(ft_encoding_unicode))exit(1);
	delete [] FONT;
	puts("font");
    }
    void RenderFont(char *str,float pos_x,float pos_y);
    int convert(char *inbuf, char *outbuf, size_t os);
    void drawString(FTFont *font, char *str);

};

#define _DATA
#endif
